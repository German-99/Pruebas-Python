def potencia(base,exponente):
     print("El resultado de la división es: ", base*exponente)

def redondear(numero):
     print("El resultado de la división es: ", round(numero))