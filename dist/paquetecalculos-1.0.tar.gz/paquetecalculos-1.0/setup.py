from setuptools import setup

setup(

    name="paquetecalculos",
    version="1.0",
    description="Paquete de calculos avanzados",
    author="Germán",
    author_email="adrian2009@live.com.mx",
    packages=["calculos","calculos.avanzados"]
)